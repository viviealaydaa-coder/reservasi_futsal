@extends('layouts.app')

@section('title', 'Edit Arena')

@push('styles')
<style>
    .form-wrapper {
        background: #0f0f0f;
        min-height: 100vh;
        padding: 40px 0;
    }
    .form-container {
        max-width: 800px;
        margin: 0 auto;
        background: #141414;
        border: 1px solid #2a2a2a;
        border-radius: 24px;
        overflow: hidden;
    }
    .form-header {
        background: linear-gradient(135deg, #e85d00, #ff7a1a);
        padding: 24px 30px;
    }
    .form-header h3 {
        color: white;
        font-weight: 700;
        margin: 0;
        font-size: 1.5rem;
    }
    .form-header p {
        color: rgba(255,255,255,0.8);
        margin: 6px 0 0;
        font-size: 0.85rem;
    }
    .form-body {
        padding: 30px;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-group label {
        display: block;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.8px;
        color: #999;
        margin-bottom: 6px;
        text-transform: uppercase;
    }
    .form-group input, 
    .form-group select, 
    .form-group textarea {
        width: 100%;
        background: #1a1a1a;
        border: 1px solid #333;
        border-radius: 10px;
        padding: 12px 16px;
        color: #e0e0e0;
        font-size: 14px;
        outline: none;
        transition: all 0.2s;
    }
    .form-group input:focus, 
    .form-group select:focus, 
    .form-group textarea:focus {
        border-color: #e85d00;
        box-shadow: 0 0 0 3px rgba(232,93,0,0.1);
    }
    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }
    .photo-section {
        background: #1a1a1a;
        border-radius: 12px;
        padding: 20px;
        margin-top: 20px;
    }
    .photo-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(100px, 100px));
        gap: 12px;
        margin-top: 15px;
    }
    .photo-item {
        position: relative;
        border-radius: 10px;
        overflow: hidden;
        background: #222;
    }
    .photo-item img {
        width: 100%;
        height: 100px;
        object-fit: cover;
    }
    .btn-delete-photo {
        position: absolute;
        top: 5px;
        right: 5px;
        background: rgba(220,53,69,0.9);
        color: white;
        border: none;
        border-radius: 20px;
        width: 24px;
        height: 24px;
        font-size: 10px;
        cursor: pointer;
        transition: all 0.2s;
    }
    .btn-delete-photo:hover {
        background: #dc3545;
    }
    .form-actions {
        display: flex;
        gap: 12px;
        margin-top: 30px;
        padding-top: 20px;
        border-top: 1px solid #2a2a2a;
    }
    .btn-save {
        background: linear-gradient(135deg, #e85d00, #ff7a1a);
        color: white;
        font-weight: 700;
        padding: 12px 24px;
        border: none;
        border-radius: 10px;
        cursor: pointer;
        transition: all 0.2s;
    }
    .btn-save:hover {
        opacity: 0.9;
        transform: translateY(-1px);
    }
    .btn-cancel {
        background: #2a2a2a;
        color: #ccc;
        font-weight: 700;
        padding: 12px 24px;
        border: none;
        border-radius: 10px;
        text-decoration: none;
        text-align: center;
        transition: all 0.2s;
    }
    .btn-cancel:hover {
        background: #3a3a3a;
        color: white;
    }
    .current-photo-label {
        font-size: 0.75rem;
        color: #e85d00;
        margin-bottom: 8px;
        display: block;
    }
</style>
@endpush

@section('content')
<div class="form-wrapper">
    <div class="form-container">
        <div class="form-header">
            <h3><i class="fas fa-edit"></i> Edit Arena</h3>
            <p>Update informasi lapangan futsal</p>
        </div>

        <div class="form-body">
            <form action="{{ route('admin.lapangans.update', $lapangan->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <div class="form-row">
                    <div class="form-group">
                        <label>Nama Arena</label>
                        <input type="text" name="name" value="{{ old('name', $lapangan->name) }}" required>
                    </div>
                    <div class="form-group">
                        <label>Tipe</label>
                        <select name="type" required>
                            <option value="indoor" {{ $lapangan->type == 'indoor' ? 'selected' : '' }}>Indoor</option>
                            <option value="outdoor" {{ $lapangan->type == 'outdoor' ? 'selected' : '' }}>Outdoor</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label>Deskripsi</label>
                    <textarea name="description" rows="3" placeholder="Deskripsi lapangan...">{{ old('description', $lapangan->description) }}</textarea>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Harga 2 Jam</label>
                        <input type="number" name="price_2jam" value="{{ old('price_2jam', $lapangan->price_2jam) }}" required>
                    </div>
                    <div class="form-group">
                        <label>Harga 3 Jam</label>
                        <input type="number" name="price_3jam" value="{{ old('price_3jam', $lapangan->price_3jam) }}" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Harga 4 Jam</label>
                        <input type="number" name="price_4jam" value="{{ old('price_4jam', $lapangan->price_4jam) }}" required>
                    </div>
                    <div class="form-group">
                        <label>Harga 5 Jam</label>
                        <input type="number" name="price_5jam" value="{{ old('price_5jam', $lapangan->price_5jam) }}" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Jam Buka</label>
                        <input type="time" name="opening_time" value="{{ old('opening_time', $lapangan->opening_time) }}" required>
                    </div>
                    <div class="form-group">
                        <label>Jam Tutup</label>
                        <input type="time" name="closing_time" value="{{ old('closing_time', $lapangan->closing_time) }}" required>
                    </div>
                </div>

                {{-- Foto Saat Ini --}}
                @if($lapangan->photos->count() > 0)
                <div class="photo-section">
                    <label class="current-photo-label"><i class="fas fa-images"></i> Foto Saat Ini</label>
                    <div class="photo-grid">
                        @foreach($lapangan->photos as $photo)
                        <div class="photo-item">
                            <img src="{{ asset('storage/'.$photo->photo_path) }}" alt="Foto lapangan">
                            <button type="button" class="btn-delete-photo" onclick="deletePhoto({{ $photo->id }})">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        @endforeach
                    </div>
                </div>
                @endif

                {{-- Upload Foto Baru --}}
                <div class="photo-section">
                    <label><i class="fas fa-upload"></i> Tambah Foto Baru</label>
                    <input type="file" name="photos[]" multiple accept="image/*" style="margin-top: 10px; background: #1a1a1a; padding: 8px; border-radius: 8px;">
                    <small style="color: #666; display: block; margin-top: 8px;">Bisa pilih lebih dari satu foto (JPG, PNG)</small>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn-save">
                        <i class="fas fa-save"></i> Simpan Perubahan
                    </button>
                    <a href="{{ route('admin.lapangans.index') }}" class="btn-cancel">
                        <i class="fas fa-times"></i> Batal
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function deletePhoto(photoId) {
    if(confirm('Yakin hapus foto ini?')) {
        fetch('{{ url("admin/lapangan-photo") }}/' + photoId, {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Content-Type': 'application/json'
            }
        }).then(response => {
            if(response.ok) {
                location.reload();
            } else {
                alert('Gagal menghapus foto');
            }
        });
    }
}
</script>
@endsection