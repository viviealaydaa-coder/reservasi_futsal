@extends('layouts.app')

@section('title', 'Tambah Arena')

@push('styles')
<style>
    .form-wrapper {
        background: #0f0f0f;
        min-height: 100vh;
        padding: 40px 0;
    }
    .form-container {
        max-width: 800px;
        margin: 0 auto;
        background: #141414;
        border: 1px solid #2a2a2a;
        border-radius: 24px;
        overflow: hidden;
    }
    .form-header {
        background: linear-gradient(135deg, #e85d00, #ff7a1a);
        padding: 24px 30px;
    }
    .form-header h3 {
        color: white;
        font-weight: 700;
        margin: 0;
        font-size: 1.5rem;
    }
    .form-header p {
        color: rgba(255,255,255,0.8);
        margin: 6px 0 0;
        font-size: 0.85rem;
    }
    .form-body {
        padding: 30px;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-group label {
        display: block;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.8px;
        color: #999;
        margin-bottom: 6px;
        text-transform: uppercase;
    }
    .form-group input, 
    .form-group select, 
    .form-group textarea {
        width: 100%;
        background: #1a1a1a;
        border: 1px solid #333;
        border-radius: 10px;
        padding: 12px 16px;
        color: #e0e0e0;
        font-size: 14px;
        outline: none;
        transition: all 0.2s;
    }
    .form-group input:focus, 
    .form-group select:focus, 
    .form-group textarea:focus {
        border-color: #e85d00;
        box-shadow: 0 0 0 3px rgba(232,93,0,0.1);
    }
    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }
    .photo-section {
        background: #1a1a1a;
        border-radius: 12px;
        padding: 20px;
        margin-top: 20px;
    }
    .form-actions {
        display: flex;
        gap: 12px;
        margin-top: 30px;
        padding-top: 20px;
        border-top: 1px solid #2a2a2a;
    }
    .btn-save {
        background: linear-gradient(135deg, #e85d00, #ff7a1a);
        color: white;
        font-weight: 700;
        padding: 12px 24px;
        border: none;
        border-radius: 10px;
        cursor: pointer;
        transition: all 0.2s;
    }
    .btn-save:hover {
        opacity: 0.9;
        transform: translateY(-1px);
    }
    .btn-cancel {
        background: #2a2a2a;
        color: #ccc;
        font-weight: 700;
        padding: 12px 24px;
        border: none;
        border-radius: 10px;
        text-decoration: none;
        text-align: center;
        transition: all 0.2s;
    }
    .btn-cancel:hover {
        background: #3a3a3a;
        color: white;
    }
    .required-star {
        color: #e85d00;
        margin-left: 4px;
    }
    small {
        color: #666;
        font-size: 0.7rem;
        display: block;
        margin-top: 5px;
    }
</style>
@endpush

@section('content')
<div class="form-wrapper">
    <div class="form-container">
        <div class="form-header">
            <h3><i class="fas fa-plus-circle"></i> Tambah Arena Baru</h3>
            <p>Masukkan informasi lapangan futsal</p>
        </div>

        <div class="form-body">
            <form action="{{ route('admin.lapangans.store') }}" method="POST" enctype="multipart/form-data">
                @csrf

                <div class="form-row">
                    <div class="form-group">
                        <label>Nama Arena <span class="required-star">*</span></label>
                        <input type="text" name="name" placeholder="Contoh: Lapangan Futsal A" required>
                    </div>
                    <div class="form-group">
                        <label>Tipe <span class="required-star">*</span></label>
                        <select name="type" required>
                            <option value="indoor">Indoor</option>
                            <option value="outdoor">Outdoor</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label>Deskripsi</label>
                    <textarea name="description" rows="3" placeholder="Deskripsi lapangan (opsional)..."></textarea>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Harga 2 Jam <span class="required-star">*</span></label>
                        <input type="number" name="price_2jam" placeholder="80000" required>
                    </div>
                    <div class="form-group">
                        <label>Harga 3 Jam <span class="required-star">*</span></label>
                        <input type="number" name="price_3jam" placeholder="120000" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Harga 4 Jam <span class="required-star">*</span></label>
                        <input type="number" name="price_4jam" placeholder="160000" required>
                    </div>
                    <div class="form-group">
                        <label>Harga 5 Jam <span class="required-star">*</span></label>
                        <input type="number" name="price_5jam" placeholder="200000" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Jam Buka <span class="required-star">*</span></label>
                        <input type="time" name="opening_time" value="08:00" required>
                    </div>
                    <div class="form-group">
                        <label>Jam Tutup <span class="required-star">*</span></label>
                        <input type="time" name="closing_time" value="22:00" required>
                    </div>
                </div>

                <div class="photo-section">
                    <label><i class="fas fa-image"></i> Foto Arena</label>
                    <input type="file" name="photos[]" multiple accept="image/*" style="margin-top: 10px; background: #1a1a1a; padding: 8px; border-radius: 8px; width: 100%;">
                    <small>Bisa pilih lebih dari satu foto (JPG, PNG, maks 2MB per foto)</small>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn-save">
                        <i class="fas fa-save"></i> Simpan Arena
                    </button>
                    <a href="{{ route('admin.lapangans.index') }}" class="btn-cancel">
                        <i class="fas fa-times"></i> Batal
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection