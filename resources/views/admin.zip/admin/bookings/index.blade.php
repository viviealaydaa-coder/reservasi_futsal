@extends('layouts.admin')

@section('title', 'Kelola Booking')

@push('styles')
<style>
    .booking-table {
        background: #111111;
        border: 1px solid #2a2a2a;
        border-radius: 16px;
        overflow: hidden;
    }
    .booking-table thead th {
        background: #1a1a1a;
        color: #8b5cf6;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.8px;
        padding: 14px 16px;
        border-bottom: 1px solid #2a2a2a;
        border-top: none;
        white-space: nowrap;
    }
    .booking-table tbody tr {
        border-bottom: 1px solid #1e1e1e;
        transition: background 0.15s;
    }
    .booking-table tbody tr:hover { background: #161616; }
    .booking-table tbody tr:last-child { border-bottom: none; }
    .booking-table tbody td {
        color: #d0d0d0;
        padding: 12px 16px;
        font-size: 13.5px;
        vertical-align: middle;
        border-top: none;
        border-bottom: 1px solid #1e1e1e;
    }
    .booking-code { font-family: 'Montserrat', sans-serif; font-weight: 700; color: #8b5cf6; font-size: 12px; letter-spacing: 0.5px; }
    .user-name { font-weight: 600; color: #e0e0e0; }
    .user-phone { font-size: 11px; color: #666; margin-top: 2px; }
    .status-badge { display: inline-flex; align-items: center; gap: 5px; padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; letter-spacing: 0.3px; }
    .badge-pending { background: rgba(100,100,100,0.2); color: #9ca3af; border: 1px solid #333; }
    .badge-waiting { background: rgba(234,179,8,0.15); color: #fbbf24; border: 1px solid rgba(234,179,8,0.3); }
    .badge-paid { background: rgba(139,92,246,0.15); color: #8b5cf6; border: 1px solid rgba(139,92,246,0.3); }
    .badge-completed { background: rgba(34,197,94,0.1); color: #4ade80; border: 1px solid rgba(34,197,94,0.2); }
    .badge-cancelled { background: rgba(239,68,68,0.1); color: #f87171; border: 1px solid rgba(239,68,68,0.2); }
    .badge-failed { background: rgba(107,114,128,0.15); color: #6b7280; border: 1px solid #2a2a2a; }
    .btn-verify { background: rgba(139,92,246,0.15); color: #8b5cf6; border: 1px solid rgba(139,92,246,0.3); border-radius: 8px; padding: 5px 12px; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s; white-space: nowrap; width: 100%; }
    .btn-verify:hover { background: #8b5cf6; color: white; }
    .btn-reject { background: rgba(239,68,68,0.1); color: #f87171; border: 1px solid rgba(239,68,68,0.2); border-radius: 8px; padding: 5px 12px; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s; white-space: nowrap; width: 100%; }
    .btn-reject:hover { background: #ef4444; color: white; border-color: #ef4444; }
    .btn-complete { background: rgba(234,179,8,0.1); color: #fbbf24; border: 1px solid rgba(234,179,8,0.2); border-radius: 8px; padding: 5px 12px; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s; white-space: nowrap; width: 100%; }
    .btn-complete:hover { background: #d97706; color: white; border-color: #d97706; }
    .btn-cancel { background: rgba(107,114,128,0.1); color: #9ca3af; border: 1px solid #2a2a2a; border-radius: 8px; padding: 5px 12px; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s; white-space: nowrap; width: 100%; }
    .btn-cancel:hover { background: #374151; color: #d1d5db; }
    .btn-proof { background: rgba(14,165,233,0.1); color: #38bdf8; border: 1px solid rgba(14,165,233,0.2); border-radius: 8px; padding: 5px 12px; font-size: 12px; font-weight: 600; text-decoration: none; transition: all 0.2s; white-space: nowrap; display: block; text-align: center; }
    .btn-proof:hover { background: #0ea5e9; color: white; }
    .filter-bar { background: #111111; border: 1px solid #2a2a2a; border-radius: 14px; padding: 16px 20px; margin-bottom: 20px; }
    .filter-bar .form-select, .filter-bar .form-control { background: #1a1a1a; border: 1px solid #2a2a2a; color: #d0d0d0; border-radius: 10px; font-size: 13.5px; padding: 9px 14px; }
    .filter-bar .form-select:focus, .filter-bar .form-control:focus { background: #1e1e1e; border-color: #8b5cf6; color: #d0d0d0; box-shadow: 0 0 0 3px rgba(139,92,246,0.12); }
    .filter-bar .form-select option { background: #1a1a1a; color: #d0d0d0; }
    .btn-search { background: #8b5cf6; color: white; border: none; border-radius: 10px; padding: 9px 18px; font-weight: 600; transition: background 0.2s; }
    .btn-search:hover { background: #7c3aed; color: white; }
    .price-cell { font-weight: 700; color: #8b5cf6; font-size: 13px; }
    .action-group { display: flex; flex-direction: column; gap: 5px; min-width: 130px; }
    .complete-inline .form-control { background: #1a1a1a; border: 1px solid #2a2a2a; color: #d0d0d0; border-radius: 8px; font-size: 12px; padding: 5px 10px; margin-bottom: 5px; }
    .complete-inline .form-control:focus { border-color: #8b5cf6; box-shadow: 0 0 0 2px rgba(139,92,246,0.15); background: #1e1e1e; color: #d0d0d0; }
    .empty-state { text-align: center; padding: 60px 20px; color: #555; }
    .empty-state i { font-size: 3rem; margin-bottom: 16px; display: block; }
    .pagination .page-link { background: #111111; border-color: #2a2a2a; color: #9ca3af; }
    .pagination .page-item.active .page-link { background: #8b5cf6; border-color: #8b5cf6; color: white; }
    .pagination .page-link:hover { background: #1a1a1a; border-color: #8b5cf6; color: #8b5cf6; }
</style>
@endpush

@section('content')
<div>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1 text-purple">Kelola Booking</h3>
            <p class="text-muted" style="font-size: 13px;">Verifikasi, konfirmasi, dan kelola semua reservasi</p>
        </div>
    </div>

    <div class="filter-bar">
        <form method="GET" class="row g-2 align-items-center">
            <div class="col-auto">
                <select name="status" class="form-select" onchange="this.form.submit()" style="min-width: 180px;">
                    <option value="">Semua Status</option>
                    <option value="pending"              {{ request('status')=='pending'              ? 'selected' : '' }}>Pending</option>
                    <option value="waiting_confirmation" {{ request('status')=='waiting_confirmation' ? 'selected' : '' }}>Menunggu Verifikasi</option>
                    <option value="paid"                 {{ request('status')=='paid'                 ? 'selected' : '' }}>Lunas</option>
                    <option value="completed"            {{ request('status')=='completed'            ? 'selected' : '' }}>Selesai</option>
                    <option value="cancelled"            {{ request('status')=='cancelled'            ? 'selected' : '' }}>Dibatalkan</option>
                    <option value="failed"               {{ request('status')=='failed'               ? 'selected' : '' }}>Gagal</option>
                </select>
            </div>
            <div class="col-auto d-flex gap-2">
                <input type="text" name="search" class="form-control"
                    placeholder="Cari nama / kode booking..."
                    value="{{ request('search') }}"
                    style="min-width: 240px;">
                <button class="btn-search" type="submit">
                    <i class="fas fa-search me-1"></i> Cari
                </button>
            </div>
        </form>
    </div>

    <div class="booking-table">
        <table class="table mb-0" style="border-collapse: collapse; width: 100%;">
            <thead>
                <tr>
                    <th>Kode</th>
                    <th>Pemesan</th>
                    <th>Lapangan</th>
                    <th>Tanggal / Jam</th>
                    <th>Total</th>
                    <th>Metode</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($bookings as $booking)
                <tr>
                    <td><span class="booking-code">{{ $booking->booking_code }}</span></td>
                    <td>
                        <div class="user-name">{{ $booking->user->name }}</div>
                        <div class="user-phone">{{ $booking->user->phone }}</div>
                    </td>
                    <td style="color: #c0c0c0; font-size: 13px;">{{ $booking->lapangan->name }}</td>
                    <td style="color: #aaa; font-size: 13px; white-space: nowrap;">
                        {{ $booking->booking_date->format('d/m/Y') }}<br>
                        <span style="font-size: 11px; color: #666;">{{ $booking->start_time }}</span>
                    </td>
                    <td class="price-cell">Rp {{ number_format($booking->total_price) }}</td>
                    <td style="font-size: 12px; color: #777; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600;">{{ $booking->payment_method }}</td>
                    <td>
                        @if($booking->payment_status == 'pending')
                            <span class="status-badge badge-pending"><i class="fas fa-clock" style="font-size:9px;"></i> Pending</span>
                        @elseif($booking->payment_status == 'waiting_confirmation')
                            <span class="status-badge badge-waiting"><i class="fas fa-hourglass-half" style="font-size:9px;"></i> Menunggu Verif</span>
                        @elseif($booking->payment_status == 'paid')
                            <span class="status-badge badge-paid"><i class="fas fa-check" style="font-size:9px;"></i> Lunas</span>
                        @elseif($booking->payment_status == 'completed')
                            <span class="status-badge badge-completed"><i class="fas fa-flag-checkered" style="font-size:9px;"></i> Selesai</span>
                        @elseif($booking->payment_status == 'cancelled')
                            <span class="status-badge badge-cancelled"><i class="fas fa-times" style="font-size:9px;"></i> Dibatalkan</span>
                        @else
                            <span class="status-badge badge-failed">{{ $booking->payment_status }}</span>
                        @endif
                    </td>
                    <td>
                        <div class="action-group">
                            @if($booking->payment_status == 'waiting_confirmation')
                                <form action="{{ route('admin.booking.verify', $booking->id) }}" method="POST">
                                    @csrf
                                    <button type="submit" class="btn-verify"><i class="fas fa-check-circle me-1"></i> Verifikasi</button>
                                </form>
                                <form action="{{ route('admin.booking.reject', $booking->id) }}" method="POST">
                                    @csrf
                                    <button type="submit" class="btn-reject"><i class="fas fa-times-circle me-1"></i> Tolak</button>
                                </form>
                            @endif
                            @if($booking->payment_status == 'paid')
                                <form action="{{ route('admin.booking.complete', $booking->id) }}" method="POST">
                                    @csrf
                                    <div class="complete-inline">
                                        <input type="text" name="damage_notes" placeholder="Catatan kerusakan" class="form-control">
                                        <input type="number" name="damage_fee" placeholder="Denda (Rp)" class="form-control">
                                    </div>
                                    <button type="submit" class="btn-complete"><i class="fas fa-flag-checkered me-1"></i> Tandai Selesai</button>
                                </form>
                            @endif
                            @if(in_array($booking->payment_status, ['pending','waiting_confirmation']))
                                <form action="{{ route('admin.booking.cancel', $booking->id) }}" method="POST">
                                    @csrf
                                    <button type="submit" class="btn-cancel"><i class="fas fa-ban me-1"></i> Batalkan</button>
                                </form>
                            @endif
                            @if($booking->payment_proof)
                                <a href="{{ asset('storage/'.$booking->payment_proof) }}" target="_blank" class="btn-proof"><i class="fas fa-image me-1"></i> Lihat Bukti</a>
                            @endif
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="8">
                        <div class="empty-state">
                            <i class="fas fa-calendar-times text-purple"></i>
                            <div style="font-weight: 600; color: #666;">Tidak ada booking ditemukan</div>
                            <div style="font-size: 12px; color: #444; margin-top: 4px;">Coba ubah filter atau kata kunci pencarian</div>
                        </div>
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($bookings->hasPages())
    <div class="mt-4 d-flex justify-content-center">
        {{ $bookings->links() }}
    </div>
    @endif
</div>
@endsection