@extends('layouts.app')

@section('title', 'Laporan Keuangan')

@section('content')
<div class="container my-5">
    <h2 class="mb-4" style="color: var(--hijau-segar);">Laporan Keuangan</h2>
    <form method="GET" class="row g-3 mb-4">
        <div class="col-md-3">
            <label>Dari Tanggal</label>
            <input type="date" name="start_date" class="form-control" value="{{ $startDate->format('Y-m-d') }}">
        </div>
        <div class="col-md-3">
            <label>Sampai Tanggal</label>
            <input type="date" name="end_date" class="form-control" value="{{ $endDate->format('Y-m-d') }}">
        </div>
        <div class="col-md-2">
            <label>Metode Pembayaran</label>
            <select name="status" class="form-select">
                <option value="">Semua</option>
                <option value="cash" {{ $status == 'cash' ? 'selected' : '' }}>Cash</option>
                <option value="qris" {{ $status == 'qris' ? 'selected' : '' }}>QRIS</option>
            </select>
        </div>
        <div class="col-md-2 align-self-end">
            <button class="btn btn-primary w-100">Filter</button>
        </div>
    </form>

    <div class="alert alert-success">
        <strong>Total Pendapatan:</strong> Rp {{ number_format($totalPendapatan) }} &nbsp;|&nbsp;
        <strong>Total Transaksi:</strong> {{ $totalTransaksi }}
    </div>

    <div class="table-responsive">
        <table class="table table-striped table-bordered bg-white">
            <thead class="table-success">
                <tr><th>Tanggal Transaksi</th><th>Kode Booking</th><th>Penyewa</th><th>Lapangan</th><th>Metode</th><th>Total Bayar</th></tr>
            </thead>
            <tbody>
                @forelse($transactions as $t)
                <tr>
                    <td>{{ $t->created_at->format('d/m/Y H:i') }}</td>
                    <td>{{ $t->booking_code }}</td>
                    <td>{{ $t->user->name }}</td>
                    <td>{{ $t->lapangan->name }}</td>
                    <td>{{ strtoupper($t->payment_method) }}</td>
                    <td>Rp {{ number_format($t->total_price) }}</td>
                </tr>
                @empty
                <tr><td colspan="6" class="text-center">Tidak ada transaksi dalam rentang ini.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection