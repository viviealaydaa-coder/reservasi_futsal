@extends('layouts.app')

@section('title', 'Dashboard Admin')

@section('content')
<div class="container my-4">

    {{-- HEADER --}}
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
        <div>
            <h2 style="font-family: 'Montserrat', sans-serif; font-weight: 800; color: #f0f0f0; margin: 0;">
                Dashboard Admin
            </h2>
            <p style="font-size: 13px; color: #777; margin-top: 4px;">
                {{ now()->translatedFormat('l, d F Y') }} — Kelola dan pantau operasional lapangan
            </p>
        </div>
        @if($pendingVerification > 0)
            <a href="{{ route('admin.bookings.index') }}?status=waiting_confirmation" class="alert-pending">
                <i class="fas fa-exclamation-circle"></i> {{ $pendingVerification }} booking menunggu verifikasi
            </a>
        @endif
    </div>

    {{-- TABEL 1: SEGERA VERIFIKASI --}}
    <div class="dashboard-panel">
        <div class="section-title">
            <i class="fas fa-clock me-2" style="color:#e85d00;"></i> Segera Verifikasi
        </div>
        <div class="section-subtitle">Booking yang belum diverifikasi (paling lama menunggu)</div>

        @if($needVerificationBookings->count() > 0)
            <div class="table-responsive">
                <table class="table-arena">
                    <thead>
                        <tr>
                            <th>Waktu Booking</th>
                            <th>Kode</th>
                            <th>Pemesan</th>
                            <th>Lapangan</th>
                            <th>Tgl & Jam</th>
                            <th>Metode</th>
                            <th>Total</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($needVerificationBookings as $booking)
                        <tr>
                            <td>{{ $booking->created_at->format('H:i, d/m') }}</td>
                            <td><span style="font-family: monospace; font-weight: 600; color:#e85d00;">{{ $booking->booking_code }}</span></td>
                            <td>{{ $booking->user->name }}<br><span style="font-size:11px;color:#777;">{{ $booking->user->phone }}</span></td>
                            <td>{{ $booking->lapangan->name }}</td>
                            <td>
                                {{ $booking->booking_date->format('d/m/Y') }}<br>
                                <span class="booking-time">{{ $booking->start_time }} ({{ $booking->duration_hours }} jam)</span>
                            </td>
                            <td>
                                @if($booking->payment_method == 'qris')
                                    <span style="background:rgba(232,93,0,0.2); padding:2px 8px; border-radius:20px; font-size:11px;">QRIS</span>
                                @elseif($booking->payment_method == 'transfer')
                                    <span style="background:rgba(59,130,246,0.2); padding:2px 8px; border-radius:20px; font-size:11px;">Transfer</span>
                                @else
                                    {{ $booking->payment_method }}
                                @endif
                            </td>
                            <td>Rp {{ number_format($booking->total_price, 0, ',', '.') }}</td>
                            <td>
                                <button type="button" class="btn-detail"
                                        data-booking="{{ $booking->toJson() }}"
                                        data-bukti="{{ $booking->payment_proof ? asset('storage/' . $booking->payment_proof) : '' }}"
                                        data-verify-route="{{ route('admin.booking.verify', $booking->id) }}"
                                        data-reject-route="{{ route('admin.booking.reject', $booking->id) }}"
                                        style="background: #3b82f6; border: none; border-radius: 6px; padding: 4px 12px; font-size: 11px; color: white; cursor: pointer;">
                                    <i class="fas fa-eye"></i> Detail & Bukti
                                </button>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @else
            <div style="text-align: center; padding: 30px; color: #666;">
                <i class="fas fa-check-circle" style="font-size: 2rem; margin-bottom: 8px; display: block; color: #4ade80;"></i>
                Tidak ada booking yang perlu verifikasi.
            </div>
        @endif
    </div>

    {{-- TABEL 2: JADWAL BOOKING HARI INI --}}
    <div class="dashboard-panel">
        <div class="section-title">
            <i class="fas fa-calendar-day me-2" style="color:#38bdf8;"></i> Jadwal Booking Hari Ini
        </div>
        <div class="section-subtitle">Booking yang sudah terkonfirmasi (paid) dan selesai</div>

        @if($todayBookings->count() > 0)
            <div class="table-responsive">
                <table class="table-arena">
                    <thead>
                        <tr>
                            <th>Jam Main</th>
                            <th>Lapangan</th>
                            <th>Pemesan</th>
                            <th>Kode Booking</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($todayBookings as $booking)
                        <tr>
                            <td><span class="booking-time">{{ $booking->start_time }} - {{ $booking->end_time }}</span></td>
                            <td><span class="lapangan-name">{{ $booking->lapangan->name }}</span></td>
                            <td>{{ $booking->user->name }}</td>
                            <td>{{ $booking->booking_code }}</td>
                            <td>
                                @if($booking->payment_status == 'paid')
                                    <span class="status-badge-sm badge-paid"><i class="fas fa-check-circle"></i> Lunas</span>
                                @elseif($booking->payment_status == 'completed')
                                    <span class="status-badge-sm badge-paid"><i class="fas fa-flag-checkered"></i> Selesai</span>
                                @elseif($booking->payment_status == 'waiting_confirmation')
                                    <span class="status-badge-sm badge-waiting">Menunggu Verif</span>
                                @else
                                    <span class="status-badge-sm badge-danger">{{ $booking->payment_status }}</span>
                                @endif
                            </td>
                            <td>
                                <a href="{{ route('booking.invoice', $booking->id) }}" target="_blank" style="color:#e85d00; font-size:12px;">Invoice</a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @else
            <div style="text-align:center; padding:30px; color:#666;">
                <i class="fas fa-calendar-times" style="font-size:2rem; margin-bottom:8px; display:block;"></i>
                Tidak ada booking untuk hari ini.
            </div>
        @endif
    </div>

    {{-- DUA KOLOM: LAPANGAN NONAKTIF + RIWAYAT VERIFIKASI --}}
    <div class="row g-3">
        <div class="col-md-6">
            <div class="dashboard-panel" style="height: 100%;">
                <div class="section-title">
                    <i class="fas fa-exclamation-triangle me-2" style="color:#f97316;"></i> Lapangan Tidak Aktif
                </div>
                <div class="section-subtitle">Perlu perhatian atau maintenance</div>

                @if($inactiveLapangans->count() > 0)
                    @foreach($inactiveLapangans as $lapangan)
                        <div class="inactive-lapangan">
                            <div style="display: flex; justify-content: space-between;">
                                <span><strong>{{ $lapangan->name }}</strong> ({{ $lapangan->type }})</span>
                                <a href="{{ route('admin.lapangans.toggle-status', $lapangan->id) }}" style="color:#ef4444; font-size:11px; text-decoration: none;" onclick="event.preventDefault(); if(confirm('Aktifkan lapangan ini?')) document.getElementById('activate-form-{{ $lapangan->id }}').submit();">
                                    <i class="fas fa-power-off"></i> Aktifkan
                                </a>
                                <form id="activate-form-{{ $lapangan->id }}" action="{{ route('admin.lapangans.toggle-status', $lapangan->id) }}" method="POST" style="display: none;">
                                    @csrf
                                </form>
                            </div>
                            <div style="font-size: 12px; margin-top: 6px; color:#aaa;">Status: <span style="color:#ef4444;">Tidak tersedia</span></div>
                        </div>
                    @endforeach
                @else
                    <div style="color:#4ade80; padding: 16px; text-align: center;">
                        <i class="fas fa-check-circle"></i> Semua lapangan aktif.
                    </div>
                @endif
            </div>
        </div>

        <div class="col-md-6">
            <div class="dashboard-panel" style="height: 100%;">
                <div class="section-title">
                    <i class="fas fa-history me-2" style="color:#8b5cf6;"></i> Verifikasi Terbaru
                </div>
                <div class="section-subtitle">Admin yang baru saja memverifikasi booking</div>

                @if($recentVerified->count() > 0)
                    <div style="max-height: 300px; overflow-y: auto;">
                        @foreach($recentVerified as $verif)
                            <div style="border-bottom: 1px solid #222; padding: 12px 0;">
                                <div style="display: flex; justify-content: space-between;">
                                    <span style="font-weight: 600;">{{ $verif->booking_code }}</span>
                                    <span style="font-size: 11px; color: #777;">{{ $verif->payment_verified_at->diffForHumans() }}</span>
                                </div>
                                <div style="font-size: 12px;">{{ $verif->lapangan->name }} | {{ $verif->user->name }}</div>
                                <div style="font-size: 11px; color:#e85d00;">
                                    <i class="fas fa-user-check"></i> Diverifikasi oleh: {{ $verif->verifier->name ?? 'System' }}
                                </div>
                            </div>
                        @endforeach
                    </div>
                @else
                    <div style="text-align:center; padding:30px; color:#666;">
                        <i class="fas fa-info-circle"></i> Belum ada verifikasi.
                    </div>
                @endif
            </div>
        </div>
    </div>

</div>

{{-- MODAL DETAIL BUKTI --}}
<div id="modalDetail" style="display: none; position: fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.8); z-index:9999; justify-content:center; align-items:center;">
    <div style="background:#1e1e1e; border-radius:16px; max-width:500px; width:90%; max-height:90%; overflow:auto; padding:20px; border:1px solid #333;">
        <div style="display:flex; justify-content:space-between; margin-bottom:16px;">
            <h4 style="margin:0; color:#e85d00;">Detail Booking & Bukti</h4>
            <button id="closeModal" style="background:none; border:none; color:#aaa; font-size:20px; cursor:pointer;">&times;</button>
        </div>
        <div id="modalContent"></div>
        <div id="modalActions" style="display:flex; gap:10px; margin-top:20px; justify-content:flex-end;"></div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    const modal = document.getElementById('modalDetail');
    const modalContent = document.getElementById('modalContent');
    const modalActions = document.getElementById('modalActions');
    const closeModal = document.getElementById('closeModal');

    function openModal(booking, buktiUrl, verifyRoute, rejectRoute) {
        let html = `
            <div style="margin-bottom:12px;"><strong>Kode Booking:</strong> ${booking.booking_code}</div>
            <div style="margin-bottom:12px;"><strong>Pemesan:</strong> ${booking.user.name} (${booking.user.phone})</div>
            <div style="margin-bottom:12px;"><strong>Lapangan:</strong> ${booking.lapangan.name}</div>
            <div style="margin-bottom:12px;"><strong>Tanggal Main:</strong> ${booking.booking_date} ${booking.start_time} (${booking.duration_hours} jam)</div>
            <div style="margin-bottom:12px;"><strong>Total Bayar:</strong> Rp ${new Intl.NumberFormat('id-ID').format(booking.total_price)}</div>
            <div style="margin-bottom:12px;"><strong>Metode:</strong> ${booking.payment_method?.toUpperCase() || '-'}</div>
            <div style="margin-bottom:16px;"><strong>Bukti Pembayaran:</strong></div>
        `;
        if (buktiUrl) {
            html += `<div><img src="${buktiUrl}" style="max-width:100%; border-radius:8px; border:1px solid #333;"></div>`;
        } else {
            html += `<div style="color:#777; padding:12px; background:#2a2a2a; border-radius:8px;">Tidak ada bukti pembayaran (mungkin metode cash atau belum upload).</div>`;
        }
        modalContent.innerHTML = html;
        modalActions.innerHTML = `
            <form action="${verifyRoute}" method="POST" style="display:inline-block;">
                @csrf
                <button type="submit" class="btn-verify" style="background:#22c55e; border:none; padding:8px 16px; border-radius:8px; color:white; cursor:pointer;">✓ Verifikasi</button>
            </form>
            <form action="${rejectRoute}" method="POST" style="display:inline-block;">
                @csrf
                <button type="submit" class="btn-reject" style="background:#ef4444; border:none; padding:8px 16px; border-radius:8px; color:white; cursor:pointer;" onclick="return confirm('Yakin tolak pembayaran ini?')">✗ Tolak</button>
            </form>
        `;
        modal.style.display = 'flex';
    }

    document.querySelectorAll('.btn-detail').forEach(btn => {
        btn.addEventListener('click', function() {
            const booking = JSON.parse(this.dataset.booking);
            const buktiUrl = this.dataset.bukti;
            const verifyRoute = this.dataset.verifyRoute;
            const rejectRoute = this.dataset.rejectRoute;
            openModal(booking, buktiUrl, verifyRoute, rejectRoute);
        });
    });

    closeModal.addEventListener('click', () => modal.style.display = 'none');
    window.addEventListener('click', (e) => { if (e.target === modal) modal.style.display = 'none'; });
</script>
@endpush